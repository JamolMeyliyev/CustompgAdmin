﻿namespace CustompgAdmin.Services.DTOs.Database;

public class CreateDatabase
{
    public required string Name { get; set; }
}
