﻿using CustompgAdmin.Services.DTOs.Column;
namespace CustompgAdmin.Services.DTOs.Table;

public class TableDto
{
    public required string Name { get; set; }
    public List<ColumnReturnDto> ColumnDtos { get; set; }
}
