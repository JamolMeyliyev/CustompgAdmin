﻿
namespace CustompgAdmin.Services.DTOs.Column;

public class ColumnReturnDto
{
    public string Name { get; set; }
}
