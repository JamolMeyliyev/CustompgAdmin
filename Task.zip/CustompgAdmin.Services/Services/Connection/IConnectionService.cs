﻿

using CustompgAdmin.DataAccess.Entities;
using CustompgAdmin.Services.DTOs.Connection;

namespace CustompgAdmin.Services.Services.Connection;

public interface IConnectionService
{
    string ConnectServer(CreateConnectionDB createConnection);
    string ConnectServerForChaeckPassword(int id, string password);
}
