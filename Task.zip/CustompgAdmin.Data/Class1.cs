﻿namespace CustompgAdmin.Data
{
    public class Class1
    {

    }
}