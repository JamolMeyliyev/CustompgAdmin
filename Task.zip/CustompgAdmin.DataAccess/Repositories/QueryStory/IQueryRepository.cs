﻿

using CustompgAdmin.DataAccess.Entities;

namespace CustompgAdmin.DataAccess.Repositories;

public interface IQueryRepository:IGenericRepository<QueryEntity,int>
{
    
}
