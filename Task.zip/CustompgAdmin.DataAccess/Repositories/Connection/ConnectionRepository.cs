﻿
using CustompgAdmin.DataAccess.Context;
using CustompgAdmin.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustompgAdmin.DataAccess.Repositories.Connection;

public class ConnectionRepository : IConnectionRepository
{
    
    public string _connectionString;
     
    public string Get()
    {
        return _connectionString;
    }
    public string ConnectServer(ConnectionEntity connectionEntity)
    {
        _connectionString = $"Host={connectionEntity.Host};Port={connectionEntity.Port};Username={connectionEntity.Username};Password={connectionEntity.Password};";
        
        return _connectionString;
    }
    

}
