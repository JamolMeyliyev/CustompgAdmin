﻿using CustompgAdmin.DataAccess.Entities;

namespace CustompgAdmin.DataAccess.Repositories;

public interface IDatabaseRepository : IGenericRepository<DatabaseEntity,int>
{

}
