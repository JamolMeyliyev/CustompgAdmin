﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustompgAdmin.DataAccess.Entities;

public enum EnumQueryStatus
{
    CREATE,
    SELECT,
    DELETE,
    OTHER
}
